goog.provide('glift.global');

glift.global = {
  /**
   * Semantic versioning of the core Glift rules/logic.
   * See: http://semver.org/
   *
   * Not yet stable.
   */
  'core-version': '0.9.2'
};
