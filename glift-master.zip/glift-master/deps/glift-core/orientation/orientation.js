goog.provide('glift.orientation');

glift.orientation = {};
