goog.provide('glift.rules');

/**
 * Objects and methods that enforce the basic rules of Go.
 */
glift.rules = {};
