goog.provide('glift.svg');

/**
 * SVG utilities. Arguably, this should be in the Glift ui. But the utilities,
 * modulo some dom-utilities, are agnostic to any rendering engine.
 */
glift.svg = {};
