# Glift Docs

Welcome to the Glift documentation.

* [Positioning and Sizing](position-size.md). *How does Glift determine the
  dimensions and orientation for the display?*
* [Styling](styling.md).
