goog.provide('glift.displays.icons');

/**
 * Objects and methods having to do with icons.
 */
glift.displays.icons = {};
