goog.provide('glift.displays.position');

glift.displays.position = {};
