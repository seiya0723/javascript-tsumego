goog.provide('glift.displays.svg');

/** SVG utilities. */
glift.displays.svg = {};
