goog.provide('glift.themes.registered.DEFAULT');

/**
 * @extends {glift.themes.base}
 */
glift.themes.registered.DEFAULT = {};
