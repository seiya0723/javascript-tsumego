goog.provide('glift.themes.registered.TEXTBOOK');

/**
 * @extends {glift.themes.base}
 */
glift.themes.registered.TEXTBOOK = {
  board: {
    fill: '#FFF'
  },

  commentBox: {
    css: {
      background: '#FFF'
    }
  }
};
