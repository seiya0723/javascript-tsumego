goog.provide('glift.themes.registered.TRANSPARENT');

/**
 * @extends {glift.themes.base}
 */
glift.themes.registered.TRANSPARENT = {
  board: {
    fill: 'none'
  },

  commentBox: {
    css: {
      background: 'none',
      border: ''
    }
  }
};
