testdata.gib = {};
testdata.gib.tygemExample =
"\\HS\n" +
"\\[GIBOKIND=Global\\]\n" +
"\\[TYPE=0\\]\n" +
"\\[SZAUDIO=0\\]\n" +
"\\[GAMECONDITION=Even : Black 6.5 Dum\\]\n" +
"\\[GAMETIME=Time limit 10minute : 30 second countdown 3 time\\]\n" +
"\\[GAMERESULT=white 59.5 win\\]\n" +
"\\[GAMEZIPSU=595\\]\n" +
"\\[GAMEDUM=0\\]\n" +
"\\[GAMEGONGJE=65\\]\n" +
"\\[GAMETOTALNUM=298\\]\n" +
"\\[GAMENAME=Rank\\]\n" +
"\\[GAMEDATE=2014- 1-27-17-54-54\\]\n" +
"\\[GAMEPLACE=Tygem Baduk\\]\n" +
"\\[GAMELECNAME=\\]\n" +
"\\[GAMEWHITENAME=Radagast (2K)\\]\n" +
"\\[GAMEWHITELEVEL=Radagast\\]\n" +
"\\[GAMEWHITECOUNTRY=3\\]\n" +
"\\[GAMEWAVATA=60011\\]\n" +
"\\[GAMEWIMAG=\\]\n" +
"\\[GAMEBLACKNAME=go48 (2K)\\]\n" +
"\\[GAMEBLACKLEVEL=16\\]\n" +
"\\[GAMEBLACKNICK=go48\\]\n" +
"\\[GAMEBLACKCOUNTRY=0\\]\n" +
"\\[GAMEBAVATA=60005\\]\n" +
"\\[GAMEBIMAGE=\\]\n" +
"\\[GAMECOMMENT=\\]\n" +
"\\[GAMEINFOMAIN=GBKIND:3,GTYPE:0,GCDT:0,GTIME:600-30-3,GRLT:1,ZIPSU:595,DUM:0,GONGJE:65,TCNT:298,AUSZ:0\\]\n" +
"\\[GAMEINFOSUB=GNAMEF:0,GPLCF:0,GNAME:Rank,GDATE:2014- 1-27-17-54-54,GPLC:Tygem Baduk,GCMT:\\]\n" +
"\\[WUSERINFO=WID:Radagast,WLV:16,WNICK:Radagast,WNCD:3,WAID:60011,WIMSG:\\]\n" +
"\\[BUSERINFO=BID:go48,BLV:16,BNICK:go48,BNCD:0,BAID:60005,BIMSG:\\]\n" +
"\\[GAMETAG=S0,R0,D0,G65,W1,Z595,T30-3-600,C2014:01:27:17:54,I:Radagast,L:16,M:go48,N:16,A:Radagast,B:go48,J:3,K:0\\]\n" +
"\\HE\n" +
"\\GS\n" +
"2 1 0\n" +
"299 0 &4\n" +
"INI 0 1 0 &4 \n" +
"STO 0 2 1 15 15 \n" +
"STO 0 3 2 3 2 \n" +
"STO 0 4 1 3 16 \n" +
"STO 0 5 2 15 3 \n" +
"STO 0 6 1 2 14 \n" +
"STO 0 7 2 13 16 \n" +
"STO 0 8 1 16 9 \n" +
"STO 0 9 2 9 15 \n" +
"STO 0 10 1 14 17 \n" +
"STO 0 11 2 5 16 \n" +
"STO 0 12 1 9 2 \n" +
"STO 0 13 2 7 2 \n" +
"STO 0 14 1 13 17 \n" +
"STO 0 15 2 12 2 \n" +
"STO 0 16 1 11 16 \n" +
"STO 0 17 2 11 15 \n" +
"STO 0 18 1 12 15 \n" +
"STO 0 19 2 10 16 \n" +
"STO 0 20 1 11 14 \n" +
"STO 0 21 2 10 15 \n" +
"STO 0 22 1 11 17 \n" +
"STO 0 23 2 16 13 \n" +
"STO 0 24 1 15 13 \n" +
"STO 0 25 2 15 12 \n" +
"STO 0 26 1 14 13 \n" +
"STO 0 27 2 16 15 \n" +
"STO 0 28 1 16 16 \n" +
"STO 0 29 2 16 14 \n" +
"STO 0 30 1 10 17 \n" +
"STO 0 31 2 8 16 \n" +
"STO 0 32 1 9 17 \n" +
"STO 0 33 2 8 17 \n" +
"STO 0 34 1 10 14 \n" +
"STO 0 35 2 16 11 \n" +
"STO 0 36 1 14 11 \n" +
"STO 0 37 2 17 16 \n" +
"STO 0 38 1 16 17 \n" +
"STO 0 39 2 16 7 \n" +
"STO 0 40 1 14 9 \n" +
"STO 0 41 2 17 17 \n" +
"STO 0 42 1 15 14 \n" +
"STO 0 43 2 8 13 \n" +
"STO 0 44 1 11 2 \n" +
"STO 0 45 2 12 3 \n" +
"STO 0 46 1 10 1 \n" +
"STO 0 47 2 2 4 \n" +
"STO 0 48 1 8 1 \n" +
"STO 0 49 2 3 9 \n" +
"STO 0 50 1 12 1 \n" +
"STO 0 51 2 2 12 \n" +
"STO 0 52 1 4 17 \n" +
"STO 0 53 2 13 1 \n" +
"STO 0 54 1 7 1 \n" +
"STO 0 55 2 6 2 \n" +
"STO 0 56 1 6 1 \n" +
"STO 0 57 2 5 2 \n" +
"STO 0 58 1 16 5 \n" +
"STO 0 59 2 15 6 \n" +
"STO 0 60 1 15 5 \n" +
"STO 0 61 2 14 5 \n" +
"STO 0 62 1 14 4 \n" +
"STO 0 63 2 15 4 \n" +
"STO 0 64 1 17 4 \n" +
"STO 0 65 2 17 3 \n" +
"STO 0 66 1 17 7 \n" +
"STO 0 67 2 14 6 \n" +
"STO 0 68 1 17 6 \n" +
"STO 0 69 2 16 2 \n" +
"STO 0 70 1 17 9 \n" +
"STO 0 71 2 17 10 \n" +
"STO 0 72 1 13 4 \n" +
"STO 0 73 2 12 5 \n" +
"STO 0 74 1 16 10 \n" +
"STO 0 75 2 12 4 \n" +
"STO 0 76 1 2 7 \n" +
"STO 0 77 2 2 8 \n" +
"STO 0 78 1 3 7 \n" +
"STO 0 79 2 5 8 \n" +
"STO 0 80 1 4 9 \n" +
"STO 0 81 2 4 8 \n" +
"STO 0 82 1 3 8 \n" +
"STO 0 83 2 2 9 \n" +
"STO 0 84 1 4 10 \n" +
"STO 0 85 2 3 11 \n" +
"STO 0 86 1 4 6 \n" +
"STO 0 87 2 6 6 \n" +
"STO 0 88 1 4 11 \n" +
"STO 0 89 2 4 12 \n" +
"STO 0 90 1 5 12 \n" +
"STO 0 91 2 5 13 \n" +
"STO 0 92 1 4 13 \n" +
"STO 0 93 2 3 12 \n" +
"STO 0 94 1 6 12 \n" +
"STO 0 95 2 6 10 \n" +
"STO 0 96 1 5 11 \n" +
"STO 0 97 2 6 13 \n" +
"STO 0 98 1 7 12 \n" +
"STO 0 99 2 1 13 \n" +
"STO 0 100 1 4 14 \n" +
"STO 0 101 2 7 13 \n" +
"STO 0 102 1 1 14 \n" +
"STO 0 103 2 5 3 \n" +
"STO 0 104 1 6 5 \n" +
"STO 0 105 2 5 5 \n" +
"STO 0 106 1 5 6 \n" +
"STO 0 107 2 6 7 \n" +
"STO 0 108 1 7 5 \n" +
"STO 0 109 2 4 5 \n" +
"STO 0 110 1 3 5 \n" +
"STO 0 111 2 3 4 \n" +
"STO 0 112 1 1 8 \n" +
"STO 0 113 2 1 9 \n" +
"STO 0 114 1 1 6 \n" +
"STO 0 115 2 0 8 \n" +
"STO 0 116 1 0 7 \n" +
"STO 0 117 2 1 7 \n" +
"STO 0 118 1 4 4 \n" +
"STO 0 119 2 5 4 \n" +
"STO 0 120 1 1 8 \n" +
"STO 0 121 2 8 12 \n" +
"STO 0 122 1 7 11 \n" +
"STO 0 123 2 1 7 \n" +
"STO 0 124 1 8 11 \n" +
"STO 0 125 2 9 11 \n" +
"STO 0 126 1 1 8 \n" +
"STO 0 127 2 9 10 \n" +
"STO 0 128 1 0 9 \n" +
"STO 0 129 2 1 11 \n" +
"STO 0 130 1 2 13 \n" +
"STO 0 131 2 0 12 \n" +
"STO 0 132 1 1 5 \n" +
"STO 0 133 2 1 4 \n" +
"STO 0 134 1 2 5 \n" +
"STO 0 135 2 9 4 \n" +
"STO 0 136 1 0 14 \n" +
"STO 0 137 2 0 13 \n" +
"STO 0 138 1 0 10 \n" +
"STO 0 139 2 1 10 \n" +
"STO 0 140 1 8 4 \n" +
"STO 0 141 2 8 3 \n" +
"STO 0 142 1 9 5 \n" +
"STO 0 143 2 10 5 \n" +
"STO 0 144 1 9 3 \n" +
"STO 0 145 2 10 4 \n" +
"STO 0 146 1 9 6 \n" +
"STO 0 147 2 10 6 \n" +
"STO 0 148 1 9 7 \n" +
"STO 0 149 2 10 9 \n" +
"STO 0 150 1 10 7 \n" +
"STO 0 151 2 11 7 \n" +
"STO 0 152 1 14 1 \n" +
"STO 0 153 2 12 0 \n" +
"STO 0 154 1 11 0 \n" +
"STO 0 155 2 11 1 \n" +
"STO 0 156 1 11 8 \n" +
"STO 0 157 2 10 8 \n" +
"STO 0 158 1 12 1 \n" +
"STO 0 159 2 14 2 \n" +
"STO 0 160 1 13 0 \n" +
"STO 0 161 2 13 2 \n" +
"STO 0 162 1 15 1 \n" +
"STO 0 163 2 16 1 \n" +
"STO 0 164 1 7 6 \n" +
"STO 0 165 2 7 8 \n" +
"STO 0 166 1 8 8 \n" +
"STO 0 167 2 8 9 \n" +
"STO 0 168 1 7 7 \n" +
"STO 0 169 2 9 8 \n" +
"STO 0 170 1 8 7 \n" +
"STO 0 171 2 7 9 \n" +
"STO 0 172 1 7 3 \n" +
"STO 0 173 2 8 2 \n" +
"STO 0 174 1 6 4 \n" +
"STO 0 175 2 6 3 \n" +
"STO 0 176 1 2 1 \n" +
"STO 0 177 2 3 1 \n" +
"STO 0 178 1 2 2 \n" +
"STO 0 179 2 2 3 \n" +
"STO 0 180 1 0 2 \n" +
"STO 0 181 2 0 3 \n" +
"STO 0 182 1 1 2 \n" +
"STO 0 183 2 5 1 \n" +
"STO 0 184 1 4 3 \n" +
"STO 0 185 2 4 2 \n" +
"STO 0 186 1 1 0 \n" +
"STO 0 187 2 0 1 \n" +
"STO 0 188 1 0 5 \n" +
"STO 0 189 2 3 3 \n" +
"STO 0 190 1 6 0 \n" +
"STO 0 191 2 4 0 \n" +
"STO 0 192 1 17 11 \n" +
"STO 0 193 2 17 12 \n" +
"STO 0 194 1 18 10 \n" +
"STO 0 195 2 14 0 \n" +
"STO 0 196 1 17 18 \n" +
"STO 0 197 2 18 15 \n" +
"STO 0 198 1 18 17 \n" +
"STO 0 199 2 17 14 \n" +
"STO 0 200 1 15 0 \n" +
"STO 0 201 2 16 0 \n" +
"STO 0 202 1 12 0 \n" +
"STO 0 203 2 11 12 \n" +
"STO 0 204 1 7 15 \n" +
"STO 0 205 2 6 15 \n" +
"STO 0 206 1 7 16 \n" +
"STO 0 207 2 7 17 \n" +
"STO 0 208 1 6 16 \n" +
"STO 0 209 2 6 17 \n" +
"STO 0 210 1 5 15 \n" +
"STO 0 211 2 7 14 \n" +
"STO 0 212 1 6 14 \n" +
"STO 0 213 2 8 15 \n" +
"STO 0 214 1 6 15 \n" +
"STO 0 215 2 10 12 \n" +
"STO 0 216 1 9 14 \n" +
"STO 0 217 2 8 14 \n" +
"STO 0 218 1 5 17 \n" +
"STO 0 219 2 12 13 \n" +
"STO 0 220 1 12 14 \n" +
"STO 0 221 2 13 13 \n" +
"STO 0 222 1 14 12 \n" +
"STO 0 223 2 13 14 \n" +
"STO 0 224 1 12 16 \n" +
"STO 0 225 2 13 15 \n" +
"STO 0 226 1 15 11 \n" +
"STO 0 227 2 16 12 \n" +
"STO 0 228 1 11 9 \n" +
"STO 0 229 2 11 10 \n" +
"STO 0 230 1 12 10 \n" +
"STO 0 231 2 12 7 \n" +
"STO 0 232 1 13 8 \n" +
"STO 0 233 2 12 11 \n" +
"STO 0 234 1 12 8 \n" +
"STO 0 235 2 13 10 \n" +
"STO 0 236 1 0 8 \n" +
"STO 0 237 2 0 11 \n" +
"STO 0 238 1 16 4 \n" +
"STO 0 239 2 16 3 \n" +
"STO 0 240 1 16 6 \n" +
"STO 0 241 2 15 8 \n" +
"STO 0 242 1 10 3 \n" +
"STO 0 243 2 14 10 \n" +
"STO 0 244 1 15 9 \n" +
"STO 0 245 2 12 9 \n" +
"STO 0 246 1 14 8 \n" +
"STO 0 247 2 13 7 \n" +
"STO 0 248 1 14 7 \n" +
"STO 0 249 2 15 7 \n" +
"STO 0 250 1 5 0 \n" +
"STO 0 251 2 3 0 \n" +
"STO 0 252 1 11 4 \n" +
"STO 0 253 2 11 5 \n" +
"STO 0 254 1 11 3 \n" +
"STO 0 255 2 14 16 \n" +
"STO 0 256 1 15 16 \n" +
"STO 0 257 2 16 8 \n" +
"STO 0 258 1 17 8 \n" +
"STO 0 259 2 18 13 \n" +
"STO 0 260 1 5 14 \n" +
"STO 0 261 2 3 13 \n" +
"STO 0 262 1 3 14 \n" +
"STO 0 263 2 5 18 \n" +
"STO 0 264 1 4 18 \n" +
"STO 0 265 2 6 18 \n" +
"STO 0 266 1 8 18 \n" +
"STO 0 267 2 18 16 \n" +
"STO 0 268 1 18 3 \n" +
"STO 0 269 2 18 2 \n" +
"STO 0 270 1 18 4 \n" +
"STO 0 271 2 13 12 \n" +
"STO 0 272 1 13 11 \n" +
"STO 0 273 2 11 13 \n" +
"STO 0 274 1 16 18 \n" +
"STO 0 275 2 4 7 \n" +
"STO 0 276 1 18 18 \n" +
"STO 0 277 2 0 4 \n" +
"STO 0 278 1 14 0 \n" +
"STO 0 279 2 18 11 \n" +
"STO 0 280 1 3 6 \n" +
"STO 0 281 2 17 10 \n" +
"STO 0 282 1 18 1 \n" +
"STO 0 283 2 17 2 \n" +
"STO 0 284 1 17 11 \n" +
"STO 0 285 2 18 12 \n" +
"STO 0 286 1 17 10 \n" +
"STO 0 287 2 9 12 \n" +
"STO 0 288 1 9 18 \n" +
"STO 0 289 2 12 10 \n" +
"STO 0 290 1 15 10 \n" +
"STO 0 291 2 5 7 \n" +
"STO 0 292 1 14 15 \n" +
"STO 0 293 2 9 13 \n" +
"STO 0 294 1 9 16 \n" +
"STO 0 295 2 10 13 \n" +
"STO 0 296 1 13 9 \n" +
"STO 0 297 2 14 14 \n" +
"STO 0 298 1 7 18 \n" +
"STO 0 299 2 15 2 \n" +
"\\GE";

testdata.gib.tygemExampleNewer =
"\\HS\n" +
"\\[GIBOKIND=Global\\]\n" +
"\\[TYPE=0\\]\n" +
"\\[SZAUDIO=0\\]\n" +
"\\[GAMECONDITION=1 Handicap\\]\n" +
"\\[GAMETIME=Time limit 20minute : 30 second countdown 3 time\\]\n" +
"\\[GAMERESULT=white wins by resignation\\]\n" +
"\\[GAMEZIPSU=0\\]\n" +
"\\[GAMEDUM=0\\]\n" +
"\\[GAMEGONGJE=0\\]\n" +
"\\[GAMETOTALNUM=54272\\]\n" +
"\\[GAMENAME=Rank\\]\n" +
"\\[GAMEDATE=2015- 6-11-16-42-35\\]\n" +
"\\[GAMEPLACE=Tygem Baduk\\]\n" +
"\\[GAMELECNAME=\\]\n" +
"\\[GAMEWHITENAME=Zellnox (2D)\\]\n" +
"\\[GAMEWHITELEVEL=Zellnox\\]\n" +
"\\[GAMEWHITECOUNTRY=3\\]\n" +
"\\[GAMEWAVATA=122\\]\n" +
"\\[GAMEWIMAG=\\]\n" +
"\\[GAMEBLACKNAME=pdy1800 (1D)\\]\n" +
"\\[GAMEBLACKLEVEL=18\\]\n" +
"\\[GAMEBLACKNICK=pdy1800\\]\n" +
"\\[GAMEBLACKCOUNTRY=0\\]\n" +
"\\[GAMEBAVATA=60001\\]\n" +
"\\[GAMEBIMAGE=\\]\n" +
"\\[GAMECOMMENT=\\]\n" +
"\\[GAMEINFOMAIN=GBKIND:3,GTYPE:0,GCDT:1,GTIME:1200-30-3,GRLT:4,ZIPSU:0,DUM:0,GONGJE:0,TCNT:54272,AUSZ:0\\]\n" +
"\\[GAMEINFOSUB=GNAMEF:0,GPLCF:0,GNAME:Rank,GDATE:2015- 6-11-16-42-35,GPLC:Tygem Baduk,GCMT:\\]\n" +
"\\[WUSERINFO=WID:Zellnox,WLV:19,WNICK:Zellnox,WNCD:3,WAID:122,WIMSG:\\]\n" +
"\\[BUSERINFO=BID:pdy1177,BLV:18,BNICK:pdy1800,BNCD:0,BAID:60001,BIMSG:\\]\n" +
"\\[GAMETAG=S0,R1,D0,G0,W4,Z0,T30-3-1200,C2015:06:11:16:42,I:Zellnox,L:19,M:pdy1177,N:18,A:Zellnox,B:pdy1800,J:3,K:0\\]\n" +
"\\HE\n" +
"\\GS\n" +
"2 1 0\n" +
"213 0 &4\n" +
"INI 0 1 0 &4 \n" +
"STO 0 2 1 3 15 \n" +
"STO 0 3 2 15 16 \n" +
"STO 0 4 1 3 3 \n" +
"STO 0 5 2 15 2 \n" +
"STO 0 6 1 15 14 \n" +
"STO 0 7 2 16 12 \n" +
"STO 0 8 1 16 14 \n" +
"STO 0 9 2 13 15 \n" +
"STO 0 10 1 13 14 \n" +
"STO 0 11 2 12 15 \n" +
"STO 0 12 1 9 16 \n" +
"STO 0 13 2 12 14 \n" +
"STO 0 14 1 13 13 \n" +
"STO 0 15 2 16 9 \n" +
"STO 0 16 1 15 4 \n" +
"STO 0 17 2 16 6 \n" +
"STO 0 18 1 16 4 \n" +
"STO 0 19 2 13 3 \n" +
"STO 0 20 1 16 2 \n" +
"STO 0 21 2 16 1 \n" +
"STO 0 22 1 17 3 \n" +
"STO 0 23 2 17 1 \n" +
"STO 0 24 1 13 4 \n" +
"STO 0 25 2 12 3 \n" +
"STO 0 26 1 12 13 \n" +
"STO 0 27 2 10 15 \n" +
"STO 0 28 1 17 11 \n" +
"STO 0 29 2 17 12 \n" +
"STO 0 30 1 17 7 \n" +
"STO 0 31 2 17 6 \n" +
"STO 0 32 1 17 9 \n" +
"STO 0 33 2 16 10 \n" +
"STO 0 34 1 16 8 \n" +
"STO 0 35 2 15 8 \n" +
"STO 0 36 1 16 11 \n" +
"STO 0 37 2 15 11 \n" +
"STO 0 38 1 17 10 \n" +
"STO 0 39 2 16 7 \n" +
"STO 0 40 1 17 8 \n" +
"STO 0 41 2 14 5 \n" +
"STO 0 42 1 15 3 \n" +
"STO 0 43 2 14 2 \n" +
"STO 0 44 1 15 10 \n" +
"STO 0 45 2 15 9 \n" +
"STO 0 46 1 15 12 \n" +
"STO 0 47 2 14 4 \n" +
"STO 0 48 1 17 5 \n" +
"STO 0 49 2 18 6 \n" +
"STO 0 50 1 17 2 \n" +
"STO 0 51 2 18 5 \n" +
"STO 0 52 1 18 4 \n" +
"STO 0 53 2 16 5 \n" +
"STO 0 54 1 18 2 \n" +
"STO 0 55 2 17 4 \n" +
"STO 0 56 1 15 7 \n" +
"STO 0 57 2 14 10 \n" +
"STO 0 58 1 17 5 \n" +
"STO 0 59 2 17 14 \n" +
"STO 0 60 1 17 15 \n" +
"STO 0 61 2 17 4 \n" +
"STO 0 62 1 14 7 \n" +
"STO 0 63 2 18 3 \n" +
"STO 0 64 1 13 9 \n" +
"STO 0 65 2 14 12 \n" +
"STO 0 66 1 15 13 \n" +
"STO 0 67 2 12 11 \n" +
"STO 0 68 1 12 10 \n" +
"STO 0 69 2 13 8 \n" +
"STO 0 70 1 14 8 \n" +
"STO 0 71 2 14 9 \n" +
"STO 0 72 1 12 8 \n" +
"STO 0 73 2 11 11 \n" +
"STO 0 74 1 10 13 \n" +
"STO 0 75 2 11 10 \n" +
"STO 0 76 1 11 9 \n" +
"STO 0 77 2 9 15 \n" +
"STO 0 78 1 8 16 \n" +
"STO 0 79 2 13 10 \n" +
"STO 0 80 1 12 9 \n" +
"STO 0 81 2 13 12 \n" +
"STO 0 82 1 9 3 \n" +
"STO 0 83 2 14 6 \n" +
"STO 0 84 1 13 7 \n" +
"STO 0 85 2 2 5 \n" +
"STO 0 86 1 2 3 \n" +
"STO 0 87 2 4 5 \n" +
"STO 0 88 1 5 3 \n" +
"STO 0 89 2 2 9 \n" +
"STO 0 90 1 2 11 \n" +
"STO 0 91 2 3 16 \n" +
"STO 0 92 1 4 16 \n" +
"STO 0 93 2 2 15 \n" +
"STO 0 94 1 2 14 \n" +
"STO 0 95 2 4 15 \n" +
"STO 0 96 1 3 14 \n" +
"STO 0 97 2 4 17 \n" +
"STO 0 98 1 5 16 \n" +
"STO 0 99 2 2 16 \n" +
"STO 0 100 1 5 17 \n" +
"STO 0 101 2 3 18 \n" +
"STO 0 102 1 16 16 \n" +
"STO 0 103 2 15 15 \n" +
"STO 0 104 1 11 17 \n" +
"STO 0 105 2 16 15 \n" +
"STO 0 106 1 17 16 \n" +
"STO 0 107 2 12 17 \n" +
"STO 0 108 1 11 16 \n" +
"STO 0 109 2 11 14 \n" +
"STO 0 110 1 11 13 \n" +
"STO 0 111 2 8 15 \n" +
"STO 0 112 1 7 15 \n" +
"STO 0 113 2 7 14 \n" +
"STO 0 114 1 12 16 \n" +
"STO 0 115 2 6 15 \n" +
"STO 0 116 1 7 16 \n" +
"STO 0 117 2 8 13 \n" +
"STO 0 118 1 6 14 \n" +
"STO 0 119 2 6 13 \n" +
"STO 0 120 1 5 14 \n" +
"STO 0 121 2 5 13 \n" +
"STO 0 122 1 4 13 \n" +
"STO 0 123 2 7 3 \n" +
"STO 0 124 1 7 2 \n" +
"STO 0 125 2 6 2 \n" +
"STO 0 126 1 6 3 \n" +
"STO 0 127 2 8 2 \n" +
"STO 0 128 1 7 1 \n" +
"STO 0 129 2 8 3 \n" +
"STO 0 130 1 8 1 \n" +
"STO 0 131 2 9 2 \n" +
"STO 0 132 1 9 1 \n" +
"STO 0 133 2 10 2 \n" +
"STO 0 134 1 2 8 \n" +
"STO 0 135 2 10 9 \n" +
"STO 0 136 1 10 8 \n" +
"STO 0 137 2 9 8 \n" +
"STO 0 138 1 9 9 \n" +
"STO 0 139 2 10 10 \n" +
"STO 0 140 1 9 7 \n" +
"STO 0 141 2 11 7 \n" +
"STO 0 142 1 10 7 \n" +
"STO 0 143 2 11 6 \n" +
"STO 0 144 1 11 8 \n" +
"STO 0 145 2 8 8 \n" +
"STO 0 146 1 8 7 \n" +
"STO 0 147 2 7 8 \n" +
"STO 0 148 1 7 7 \n" +
"STO 0 149 2 6 8 \n" +
"STO 0 150 1 6 7 \n" +
"STO 0 151 2 6 5 \n" +
"STO 0 152 1 5 8 \n" +
"STO 0 153 2 5 9 \n" +
"STO 0 154 1 4 8 \n" +
"STO 0 155 2 5 7 \n" +
"STO 0 156 1 5 6 \n" +
"STO 0 157 2 4 7 \n" +
"STO 0 158 1 6 9 \n" +
"STO 0 159 2 8 9 \n" +
"STO 0 160 1 4 6 \n" +
"STO 0 161 2 3 7 \n" +
"STO 0 162 1 3 6 \n" +
"STO 0 163 2 2 7 \n" +
"STO 0 164 1 2 6 \n" +
"STO 0 165 2 3 8 \n" +
"STO 0 166 1 6 6 \n" +
"STO 0 167 2 1 6 \n" +
"STO 0 168 1 8 10 \n" +
"STO 0 169 2 4 9 \n" +
"STO 0 170 1 9 10 \n" +
"STO 0 171 2 9 12 \n" +
"STO 0 172 1 7 12 \n" +
"STO 0 173 2 7 13 \n" +
"STO 0 174 1 5 11 \n" +
"STO 0 175 2 4 12 \n" +
"STO 0 176 1 4 11 \n" +
"STO 0 177 2 3 13 \n" +
"STO 0 178 1 4 14 \n" +
"STO 0 179 2 5 12 \n" +
"STO 0 180 1 7 9 \n" +
"STO 0 181 2 5 8 \n" +
"STO 0 182 1 3 12 \n" +
"STO 0 183 2 4 3 \n" +
"STO 0 184 1 4 4 \n" +
"STO 0 185 2 6 11 \n" +
"STO 0 186 1 11 1 \n" +
"STO 0 187 2 10 1 \n" +
"STO 0 188 1 10 0 \n" +
"STO 0 189 2 4 2 \n" +
"STO 0 190 1 5 2 \n" +
"STO 0 191 2 5 4 \n" +
"STO 0 192 1 3 4 \n" +
"STO 0 193 2 6 4 \n" +
"STO 0 194 1 5 1 \n" +
"STO 0 195 2 3 5 \n" +
"STO 0 196 1 11 2 \n" +
"STO 0 197 2 5 5 \n" +
"STO 0 198 1 7 4 \n" +
"STO 0 199 2 7 5 \n" +
"STO 0 200 1 8 4 \n" +
"STO 0 201 2 10 3 \n" +
"STO 0 202 1 11 3 \n" +
"STO 0 203 2 10 4 \n" +
"STO 0 204 1 11 5 \n" +
"STO 0 205 2 11 4 \n" +
"STO 0 206 1 10 5 \n" +
"STO 0 207 2 12 6 \n" +
"STO 0 208 1 8 5 \n" +
"STO 0 209 2 12 5 \n" +
"STO 0 210 1 1 5 \n" +
"STO 0 211 2 1 4 \n" +
"STO 0 212 1 7 6 \n" +
"STO 0 213 2 0 5 \n" +
"\\GE\n";
